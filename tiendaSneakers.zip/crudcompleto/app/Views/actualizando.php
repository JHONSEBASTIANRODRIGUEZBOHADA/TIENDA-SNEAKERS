<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
</head>

<body>
    <style>
            body {
                background-color: aquamarine;
            }
        </style>
    <div class="container"><br> <br>
        <div class="container-fluid">
            <h1>Actualizar</h1>
            <form action="<?= base_url('factualizar'); ?>" method="POST">
                <div class="form-group">
                    <input type="number" hidden name="id" value="<?= $persona['id'] ?>">
                    <label for="exampleInputEmail1">Marca</label>
                    <input type="text" class="form-control" id="marca" name="marca" value="<?= $persona['marca'] ?>" required aria-describedby="emailHelp">

                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Color</label>
                    <input type="text" class="form-control" id="color" name="color" value="<?= $persona['color'] ?>" required aria-describedby="emailHelp">

                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Talla</label>
                    <input type="number" class="form-control" id="talla" name="talla" value="<?= $persona['talla'] ?>" required aria-describedby="emailHelp">

                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Cantidad</label>
                    <input type="number" class="form-control" id="cantidad" name="cantidad" value="<?= $persona['cantidad'] ?>" required aria-describedby="emailHelp">

                </div><br>
                <div class="form-group">
                    <label for="exampleInputEmail1">Precio</label>
                    <input type="number" class="form-control" id="precio" name="precio" value="<?= $persona['precio'] ?>" required aria-describedby="emailHelp">

                </div><br>

                <button type="submit" class="btn btn-primary">Actualizar</button>
            </form>
        </div>
    </div>

</body>

</html>