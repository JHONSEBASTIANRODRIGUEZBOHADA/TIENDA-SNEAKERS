<!DOCTYPE html>
<html lang="en">

<head>
	<title></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/style.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
</head>

<body>
	<section class="hero is-primary">
        <div class="hero-body">
            <p class="title">SNEAKERS</p>
            <p class="subtitle">venta de sneakers</p>
        </div>
    </section><br>
	<div class="container"><br> <br>
		<div class="container-fluid">
			<table class="table table-striped table-dark">
				<thead>
				<tr>
						<th scope="col">Id</th>
						<th scope="col">Marca</th>
						<th scope="col">Color</th>
						<th scope="col">Talla</th>
						<th scope="col">cantidad</th>
						<th scope="col">Precio</th>
						<th scope="col">Botones</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($personas as $per) :
						# code...
					?>
						<tr>
							<th scope="row"> <?= $per['id'] ?></th>
							<td><?= $per['marca'] ?></td>
							<td><?= $per['color'] ?></td>
							<td><?= $per['talla'] ?></td>
							<td><?= $per['cantidad'] ?></td>
							<td><?= $per['precio'] ?></td>
							<td><a href="<?php echo base_url('editar/' . $per['id']) ?>"><button type="button">Actualizar</button></a> <a href="<?php echo base_url('eliminar/' . $per['id']) ?>"><button type="button">Eliminar</button></a></td>

						</tr>
					<?php endforeach;

					?>
				</tbody>
			</table>
			<div>
				<a href="<?php echo base_url('agregar'); ?>"> <button type="button" class="btn btn-primary">agregar</button></a>
			</div><br>
		</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
</body>

</html>